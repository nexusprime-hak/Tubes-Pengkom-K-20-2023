# import time

# frame = [
#     [
#         '  ||',
#         '==  ==',
#         '==  ==',
#         '  ||',
#     ],
#     [
#         ' \ /',
#         '\   /',
#         '/   \ ',
#         ' / \ ',
#     ]
# ]


# for i in range(100):
#     for j in frame:
#         print('\r',j[0],sep='',end='',flush=True)
#         print('\r',j[1],sep='',end='',flush=True)
#         print('\r',j[2],sep='',end='',flush=True)
#         print('\r',j[3],sep='',end='',flush=True)
#         time.sleep(0.2)

print("a")
print("b")